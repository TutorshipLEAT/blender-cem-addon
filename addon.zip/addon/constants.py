VOXELS_DIR = "export/voxels"
DEPENDENCIES = ['seaborn', 'trimesh', 'matplotlib', 'pandas', 'numpy', 'scipy']
VISUALISATIONS_DIR = "export/visualizations"