VOXELS_DIR = "export/voxels"
VISUALISATIONS_DIR = "export/visualizations"